#!/usr/bin/python
# coding=utf-8

import MySQLdb
import codecs

# 商城道具配置表
ibItemTotal = {}

# 读取商城配置表
def readIBItemId(fileName):
    # oputput = open(fileName, 'r' )
    output = codecs.open(fileName, 'r', 'utf-8')
    for line in output:
        tmpStr = line.split(',')
        ibItemTotal[int(tmpStr[0])] = ((int)(tmpStr[0]), tmpStr[1].strip('\n'))

    # print ibItemTotal
    output.close()


# 读取logItem表
def selectFromItemLog(filename, hostName, sqlPort, userName, pwd, databaseName, day):
    dicRoleItemLog = {}
    conn = MySQLdb.connect(host=hostName, user=userName, passwd=pwd, port=sqlPort)
    curs = conn.cursor()
    curs.execute('use ' + databaseName)
    tableName = '%s_LOG_ROLE_ITEM_01' % day
    sqlRoleItemLog = 'select item_id,op_type,item_num from %s where op_type not in (2,3,4,43,50,51,52,82,89);' % tableName

    output = open(filename, 'w')
    # output.write('道具ID,昨天,今天,增加,减少\n')

    n = curs.execute(sqlRoleItemLog)
    for row in curs.fetchall():
        if ibItemTotal.get(row[0]) is None:
            continue

        # 元组格式（itemId, create, remove, sell, rebuy  )
        if dicRoleItemLog.get(row[0]) is None:
            dicRoleItemLog[row[0]] = (row[0], 0, 0, 0, 0)

        pairNum = dicRoleItemLog[row[0]]

        itemId = row[0]
        create = pairNum[1]
        remove = pairNum[2]
        sell = pairNum[3]
        rebuy = pairNum[4]
        logItemCount = row[2]

        # 大于50是失去，小于50获得
        if (row[1] > 50):
            # if( row[1] != 66 ):
            dicRoleItemLog[itemId] = (itemId, create, remove + logItemCount, sell, rebuy)

            # 25回购，66卖店
            if (row[1] == 66):
                dicRoleItemLog[itemId] = (itemId, create, remove, sell + logItemCount, rebuy)
        else:
            # if( row[1] != 25 ):
            dicRoleItemLog[itemId] = (itemId, create + logItemCount, remove, sell, rebuy)

            # 25回购，66卖店
            if (row[1] == 25):
                dicRoleItemLog[itemId] = (itemId, create, remove, sell, rebuy + logItemCount)

    curs.close()
    for item, v in ibItemTotal.items():
        diff = dicRoleItemLog.get(item) or (item, 0, 0, 0, 0)

        deltaSellAndRebuy = diff[3] - diff[4]
        if (deltaSellAndRebuy < 0):
            deltaSellAndRebuy = 0

        if (diff[1] > 0 or diff[2] + deltaSellAndRebuy > 0):
            output.write('%d,%d,%d\n' % (item, diff[1], diff[2] + deltaSellAndRebuy))
    # print dicRoleItemLog
    return dicRoleItemLog

# 开始计算平衡关系
readIBItemId('ibitem.txt')

print '------------- LXD_0401  ------------------'
diffItemLog = selectFromItemLog('LXD_0401.csv', '172.16.6.17', 3306, 'xyj', 'bl[DzHs4PJ5@xyj', 'LogDB_LingXD',
                                '20140401')
print '------------- LXD_0402  ------------------'
diffItemLog = selectFromItemLog('LXD_0402.csv', '172.16.6.17', 3306, 'xyj', 'bl[DzHs4PJ5@xyj', 'LogDB_LingXD',
                                '20140402')
print '------------- LXD_0403  ------------------'
diffItemLog = selectFromItemLog('LXD_0403.csv', '172.16.6.17', 3306, 'xyj', 'bl[DzHs4PJ5@xyj', 'LogDB_LingXD',
                                '20140403')
print '------------- LXD_0404  ------------------'
diffItemLog = selectFromItemLog('LXD_0404.csv', '172.16.6.17', 3306, 'xyj', 'bl[DzHs4PJ5@xyj', 'LogDB_LingXD',
                                '20140404')
print '------------- LXD_0405  ------------------'
diffItemLog = selectFromItemLog('LXD_0405.csv', '172.16.6.17', 3306, 'xyj', 'bl[DzHs4PJ5@xyj', 'LogDB_LingXD',
                                '20140405')
print '------------- LXD_0406  ------------------'
diffItemLog = selectFromItemLog('LXD_0406.csv', '172.16.6.17', 3306, 'xyj', 'bl[DzHs4PJ5@xyj', 'LogDB_LingXD',
                                '20140406')
print '------------- LXD_0407  ------------------'
diffItemLog = selectFromItemLog('LXD_0407.csv', '172.16.6.17', 3306, 'xyj', 'bl[DzHs4PJ5@xyj', 'LogDB_LingXD',
                                '20140407')
