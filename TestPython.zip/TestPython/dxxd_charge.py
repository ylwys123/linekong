#!/usr/bin/python 
# coding=utf-8

import MySQLdb


def dxxdMoneyQuery(databaseName):
    conn = MySQLdb.connect(host='127.0.0.1', user='root', passwd='hh5MhnI9c')
    curs = conn.cursor()
    curs.execute('show databases')
    curs.execute('use ' + databaseName)

    curs.execute('select rating_id from lk_charge_info_0 limit 1')
    ratingId = curs.fetchone()

    chargeTotal = 0
    for x in range(64):
        sql = 'select sum(amount) from lk_charge_info_%s' % x
        curs.execute(sql)
        charge = curs.fetchone()
        chargeTotal += charge[0]

    curs.execute('select sum(discount_price*count) from lk_ib_pay_info where subject_id=5')
    consume = curs.fetchone()

    print 'gatewayId,totalCharge,totalConsume'
    print  '%s,%s,%s' % (ratingId[0], chargeTotal, consume[0])


dxxdMoneyQuery('lk_account')
