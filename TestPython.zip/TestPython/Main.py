__author__ = 'Administrator'

import MySQLdb


def writeFile():
    output = open('test.csv', 'w')
    output.write('a,b,c,d\n')
    output.write('a,b,c,d\n')
    output.write('a,b,c,d\n')
    output.close()


def readData():
    conn = MySQLdb.connect(host='127.0.0.1', user='root', passwd='ylwys5312656')
    curs = conn.cursor()
    curs.execute('show databases')
    curs.execute('use s2_server_work_log')
    curs.execute('select DISTINCT userId from t_log_coin')
    data = curs.fetchall()
    for row in data:
        userId = row[0]
        inSql = 'select temp.playType, SUM(changeNum) from (select *  from t_log_coin WHERE userId = ' + userId + ') as temp where temp.changeNum > 0 group by temp.playType'
        curs.execute(inSql)
        data = curs.fetchall()
        for row in data:


readData()
