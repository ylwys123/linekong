#!/usr/bin/python
#coding=utf-8


import MySQLdb

serverList=( 'hs', 'jg', 'jy', 'lf', 'sd', 'wz', 'xa', 'thd' )


conn =  MySQLdb.connect(host='127.0.0.1', user='root', passwd='', unix_socket='/tmp/mysql.sock')
curs = conn.cursor()



def queryGoldBalancePerUser(databaseName, gatewayId):
    curs.execute( 'use ' + databaseName )

    #chargeSql = 'select userId,sum(amount) from payLog where Type=3 group by userId'
    #consumeSql = 'select UserId,sum(price) from shoplog where priceType=3 group by UserId' 
    balanceSql = 'select cs_uId, cm_uRmbMoney from tbl_char_money group by cs_uId'

    dicCharge = {}
    dicConsume = {}
    dicBalance = {}


    n=curs.execute( balanceSql )
    print 'balance %d' %n 
    for row in curs.fetchall():
        dicBalance[row[0]] = row

    filename = 'yb_gold_balance_%d.csv' % gatewayId
    output = open( filename, 'w')
    output.write('账号,余额\n')


    for k,v in dicBalance.items():
        output.write('%d,%d\n' %(k,v[1]))

    output.close()



def queryAllServerGold():
    queryGoldBalancePerUser('BingFDL_MDB_20131231', 808090)  
    queryGoldBalancePerUser('BingHZG_MDB_20131231', 808048)  
    queryGoldBalancePerUser('HuiJSM_MDB_20131231', 808050)  
    queryGoldBalancePerUser('MoFSL_MDB_20131231', 808003)  
    queryGoldBalancePerUser('QingFZY_MDB_20131231', 808024)  


queryAllServerGold()


