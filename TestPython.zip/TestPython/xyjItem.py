#!/usr/bin/python
#coding=utf-8

import MySQLdb
import codecs

#商城道具配置表
ibItemTotal = {}

#读取商城配置表
def readIBItemId(fileName):
    #oputput = open(fileName, 'r' )
    output = codecs.open(fileName, 'r', 'utf-8')
    for line in output:
        tmpStr = line.split(',')
	ibItemTotal[int(tmpStr[0])] = ( (int)(tmpStr[0]), tmpStr[1].strip('\n' ) )

    #print ibItemTotal
    output.close()
	
def readItem(fileName):
    output = open(fileName, 'r' )
    dicItemLog = {}
    for line in output:
        tmpStr = line.split(',')
        itemid = int(tmpStr[0])
        lastday = int(tmpStr[1])
        today = int(tmpStr[2])
	dicItemLog[itemid] = ( itemid,lastday, today )

        #print dicItemLog 
    output.close()
    #print dicItemLog 
    return dicItemLog
	
def readLog(fileName):
    output = open(fileName, 'r' )
    dicItemLog = {}
    for line in output:
        tmpStr = line.split(',')
        itemid = int(tmpStr[0])
        lastday = int(tmpStr[1])
        today = int(tmpStr[2])
	dicItemLog[itemid] = ( itemid,lastday, today )

    #print ibItemTotal
    output.close()
    return dicItemLog


#平衡关系确认
def checkBalance(file,lastDay,todayDiff):
    output = open(file, 'w')
    output.write('道具ID,昨天,今天,增加,减少\n')
    for item,v in ibItemTotal.items():
        lastDayLeft = lastDay.get(item) or (item,0,0)
        diff = todayDiff.get(item) or (item,0,0)
        
        
        if( lastDayLeft[1] > 0  or diff[1] > 0 or diff[2] > 0 ):
            output.write('%d,%d,%d,%d,%d\n' % (item,lastDayLeft[1],lastDayLeft[2],diff[1],diff[2]))
    output.close() 





# 开始计算平衡关系
readIBItemId('ibitem.txt')

a = readItem('HGSITEM_0401.csv')
b = readLog('HGS_0000.csv')
checkBalance('HGS1.csv',a,b)

a = readItem('HJSITEM_0401.csv')
b = readLog('HJS_0000.csv')
checkBalance('HJS1.csv',a,b)

a = readItem('JBPITEM_0401.csv')
b = readLog('JBP_0000.csv')
checkBalance('JBP1.csv',a,b)

a = readItem('JGTMITEM_0401.csv')
b = readLog('JGTM_0000.csv')
checkBalance('JGTM1.csv',a,b)

a = readItem('LLYITEM_0401.csv')
b = readLog('LLY_0000.csv')
checkBalance('LLY1.csv',a,b)

a = readItem('JHSYITEM_0401.csv')
b = readLog('JHSY_0000.csv')
checkBalance('JHSY1.csv',a,b)

a = readItem('LXDITEM_0401.csv')
b = readLog('LXD_0000.csv')
checkBalance('LXD1.csv',a,b)
