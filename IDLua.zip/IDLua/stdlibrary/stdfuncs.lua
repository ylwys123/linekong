assert = _G.assert
collectgarbage = _G.collectgarbage
dofile = _G.dofile
error = _G.error
getfenv = _G.getfenv
getmetatable = _G.getmetatable
ipairs  = _G.ipairs 
load = _G.load
loadfile  = _G.loadfile 
loadstring  = _G.loadstring 
next = _G.next
pairs = _G.pairs
pcall  = _G.pcall 
print  = _G.print 
rawequal  = _G.rawequal 
rawget  = _G.rawget 
rawset  = _G.rawset 
select  = _G.select 
setfenv  = _G.setfenv 
setmetatable  = _G.setmetatable 
tonumber  = _G.tonumber 
tostring  = _G.tostring 
type  = _G.type 
unpack  = _G.unpack 
xpcall  = _G.xpcall 
module  = _G.module 
require  = _G.require 

_VERSION = "string"
_M = {}








